package com.phegondev.usersmanagementsystem.config;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.phegondev.usersmanagementsystem.service.JWTUtils;
import com.phegondev.usersmanagementsystem.service.OurUserDetailsService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JWTAuthFilter extends OncePerRequestFilter{
	
	@Autowired
	private JWTUtils jwtUtils;
	
	@Autowired
	private OurUserDetailsService ourUserDetailsService;
	
	//Todo lo que venga de un request pasara por aqui abajo
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//el usuario is gonna generate a token y este usuario hace un http request al backend y va a pasar ese tokenn por el header
		//y lo va a pasar aqui que lo va a interceptar y aqui se extracatara es etoken
		final String authHeader = request.getHeader("Authorization");
		final String jwtToken;
		final String userEmail;
		if(authHeader == null || authHeader.isBlank()) {
			filterChain.doFilter(request, response);
			return;
		}
		//cuando se pasa la autorizacion se pasa con una barrera token y aqui se elimina   "bearer"
		jwtToken=authHeader.substring(7);
		userEmail=jwtUtils.extractUsername(jwtToken);
		
		if(userEmail!=null && SecurityContextHolder.getContext().getAuthentication()==null) {
			UserDetails userDetails = ourUserDetailsService.loadUserByUsername(userEmail);
			
			if(jwtUtils.isTokenValid(jwtToken, userDetails)) {
				SecurityContext securityContext=SecurityContextHolder.createEmptyContext();
				UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
						userDetails, null, userDetails.getAuthorities()
				);
				token.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				securityContext.setAuthentication(token);
				SecurityContextHolder.setContext(securityContext);
			}
		}
		filterChain.doFilter(request, response);
		
	}

}
